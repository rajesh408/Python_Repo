print ("password please\n")

password = input("Enter your password: ")

if password == "name":
    print ("Access Granted")
else:
    print ("Access Denied")
