import sys

print("Hello {}. Welcome to {}".format(sys.argv[1], sys.argv[2]))