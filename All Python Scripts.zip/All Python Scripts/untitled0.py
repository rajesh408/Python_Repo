# -*- coding: utf-8 -*-
"""
Created on Fri Oct 23 10:47:16 2020

@author: Rajesh
"""

print('Hi Python')