# import module by renaming it

import math as m
print("The value of pi is", m.pi)