# import all names form
# the standard module math

from math import *
print("The value of pi is", pi)