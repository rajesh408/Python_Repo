#we have the input() function so the user can input values

num = input('Enter a number: ')
print(num)
