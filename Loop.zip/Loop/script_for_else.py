digits = [0, 1, 5]

for i in digits:
    print(i)
else:
    print("No items left.")