#!/usr/bin/env python
# coding: utf-8

# In[2]:


print(0b100)


# In[5]:


import fractions
print(fractions.Fraction(1.1))
print(fractions.Fraction('1.1'))


# In[7]:


import math

print(math.pi)


# In[10]:


import math

num = int(input('Enter any number'))
print (math.factorial(num))


# In[11]:


import math

print(math.cos(math.pi))


# In[14]:


my_list = ['P','Y','T','H','O','N']
print(my_list[-1])


# In[16]:


course_list = ["C","C++","Python","JAVA"]
print(course_list[-2])


# In[17]:


product_list = [1001,"Laptop",50000,5]
print('Laptop price is : ',product_list[2])


# In[20]:


n_list = ["Happy", [2,0,1,5]]
print(n_list[0][1])
print(n_list[0])
print(n_list[1][0])


# In[24]:


odd =[2,4,6,8]
print(odd)
odd[0] =1
print(odd)
odd[1:3] = [3,5]  
print(odd)


# In[25]:


my_list = [1,2,3,4,5]
my_list[2::2] = [0,0]
print(my_list)


# In[30]:


n_list = [[0,0,0,0], [1,1,1,1]]
n_list[0][1:3] =[2,2] 
n_list[1][2:4] =[4,4]
print(n_list[0])
print(n_list[1])

print(n_list)







